function getQueryReferenceSdef(div)
{
	return getInputSdef(div);
}
