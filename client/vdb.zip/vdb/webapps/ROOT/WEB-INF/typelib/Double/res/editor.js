function getDoubleSdef(div)
{
	return getInputSdef(div);
}
