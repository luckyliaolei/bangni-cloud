function getQueryDoubleSdef(div)
{
	return getInputSdef(div);
}