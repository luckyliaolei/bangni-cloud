function getTreeSdef(div)
{
	return getInputSdef(div);
}
