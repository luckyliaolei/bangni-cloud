function getQueryTreeSdef(div)
{
	return getInputSdef(div);
}