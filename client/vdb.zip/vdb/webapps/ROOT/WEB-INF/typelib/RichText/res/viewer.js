function getQueryRichTextSdef(div)
{	
	return getInputSdef(div);
}