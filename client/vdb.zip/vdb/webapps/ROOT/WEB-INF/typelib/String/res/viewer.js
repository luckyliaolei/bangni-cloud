function getQueryStringSdef(div)
{
	return getInputSdef(div);
}