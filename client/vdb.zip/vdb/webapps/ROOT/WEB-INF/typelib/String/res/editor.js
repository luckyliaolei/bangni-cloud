function getStringSdef(div)
{
	return getInputSdef(div);
}
