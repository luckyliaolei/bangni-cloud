function getQueryEnumSdef(div)
{
	return getInputSdef(div);
}