function getQueryMultiSelectSdef(div)
{
	return getInputSdef(div);
}