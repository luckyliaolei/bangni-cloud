function getQueryChemStructureSdef(div)
{
	return getInputSdef(div);
}