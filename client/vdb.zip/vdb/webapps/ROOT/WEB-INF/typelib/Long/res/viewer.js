function getQueryLongSdef(div)
{
	return getInputSdef(div);
}