function getLongSdef(div)
{
	return getInputSdef(div);
}
