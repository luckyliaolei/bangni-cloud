function getHyperLinkSdef(div)
{
	return getInputSdef(div);
}
