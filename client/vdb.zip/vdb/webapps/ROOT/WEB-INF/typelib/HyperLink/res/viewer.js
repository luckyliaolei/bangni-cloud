function getQueryHyperLinkSdef(div)
{
	return getInputSdef(div);
}