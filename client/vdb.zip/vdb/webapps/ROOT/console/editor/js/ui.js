function showEntity(euri)
{
	loadHTML1("table.vpage", "euri=" + euri, document.getElementById("MainArea"));
}
