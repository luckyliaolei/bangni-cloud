//v.2.5 build 090904

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["4L"] = '<layout><autosize hor="c;d" ver="a;b;d" rows="2" cols="3"/><table data="a,b,c;a,b,d"/><row><cell obj="a" wh="3,1" resize="hor" neighbors="a;b;c,d" rowspan="3"/><cell sep="ver" left="a" right="b;c,d" dblclick="a" rowspan="3"/><cell obj="b" wh="3,1" resize="hor" neighbors="a;b;c,d" rowspan="3"/><cell sep="ver" left="a;b" right="c,d" dblclick="b" rowspan="3"/><cell obj="c" wh="3,2" resize="ver" neighbors="c;d"/></row><row sep="true"><cell sep="hor" top="c" dblclick="c" bottom="d"/></row><row><cell obj="d" wh="c,2" resize="ver" neighbors="c;d"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["4L_hor"] = new Array("a", "b", "c;d");dhtmlXLayoutObject.prototype._availAutoSize["4L_ver"] = new Array("a;b;c", "a;b;d");

//v.2.5 build 090904

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/