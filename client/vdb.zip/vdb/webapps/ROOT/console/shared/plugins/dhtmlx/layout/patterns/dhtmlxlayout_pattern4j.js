//v.2.5 build 090904

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["4J"] = '<layout><autosize hor="a;b;d" ver="c;d" rows="3" cols="2"/><table data="a,a;b,b;c,d"/><row><cell obj="a" wh="1,3" resize="ver" neighbors="a;b;c,d" colspan="3"/></row><row sep="true"><cell sep="hor" top="a" bottom="b;c,d" dblclick="a" colspan="3"/></row><row><cell obj="b" wh="1,3" resize="ver" neighbors="a;b;c,d" colspan="3"/></row><row sep="true"><cell sep="hor" top="a;b" bottom="c,d" dblclick="b" colspan="3"/></row><row><cell obj="c" wh="2,3" resize="hor" neighbors="c;d"/><cell sep="ver" left="c" right="d" dblclick="c"/><cell obj="d" wh="2,3" resize="hor" neighbors="c;d"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["4J_hor"] = new Array("a;b;c", "a;b;d");dhtmlXLayoutObject.prototype._availAutoSize["4J_ver"] = new Array("a", "b", "c;d");

//v.2.5 build 090904

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/