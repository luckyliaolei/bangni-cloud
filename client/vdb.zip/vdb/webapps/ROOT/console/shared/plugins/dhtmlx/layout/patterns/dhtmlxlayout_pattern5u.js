//v.2.5 build 090904

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXLayoutObject.prototype.tplData["5U"] = '<layout><autosize hor="d;e" ver="e" rows="2" cols="4"/><table data="a,b,c,d;e,e,e,e"/><row><cell obj="a" wh="4,2" resize="hor" neighbors="a;b;c;d"/><cell sep="ver" left="a" right="b;c;d" dblclick="b"/><cell obj="b" wh="4,2" resize="hor" neighbors="a;b;c;d"/><cell sep="ver" left="b;b" right="c;d" dblclick="c"/><cell obj="c" wh="4,2" resize="hor" neighbors="a;b;c;d"/><cell sep="ver" left="a;b;c" right="d" dblclick="d"/><cell obj="d" wh="4,2" resize="hor" neighbors="a;b;c;d"/></row><row sep="true"><cell sep="hor" top="a,b,c,d" bottom="e" dblclick="e" colspan="7"/></row><row><cell obj="e" wh="1,2" resize="ver" neighbors="a,b,c,d;e" colspan="7"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["5U_hor"] = new Array("a;e", "b;e", "c;e", "d;e");dhtmlXLayoutObject.prototype._availAutoSize["5U_ver"] = new Array("a;b;c;d", "e");

//v.2.5 build 090904

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/